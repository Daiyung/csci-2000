#!/bin/bash
cd /home/vin#!/bin/bashcent/Documents/csci2000u/assignments_1/
find data/ -name NOTES -exec rm -f {} \;
mkdir cleaned_data
find /home/vincent/Documents/csci2000u/assignments/assignment_1/data/ -type f -exec mv {} ~/Documents/csci2000u/assignments/assignment_1/cleaned_data/ \;
cd /home/vincent/Documents/csci2000u/assignments/assignment_1/cleaned_data
for f in *; do mv $f `basename $f `.txt; done;
